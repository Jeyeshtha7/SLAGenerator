
## Stack: React (Vite) + Node.js (Express) + MySQL



###  What this project does & what we used

#### Goal
A responsive online bookstore with:

- Home page – intro to bookstore
- Login page – login with email + password
- Registration page – create a new user
- Catalog page – show books, search by title/author/genre

## Tech used

# Backend (Node)

Node.js + Express — to create backend server and REST APIs

MySQL2 — to connect backend with MySQL database

bcrypt — to hash passwords securely (no plain text password stored)

jsonwebtoken (JWT login token) — to generate secure login tokens for authentication

cors — to allow React frontend to access backend APIs

dotenv — to store DB password and JWT secret in .env instead of hardcoding

# Frontend

React (Vite) — to build fast and modular frontend UI

React Router (react-router-dom) — to navigate between pages without reloading

Axios — to make API calls to backend (GET / POST)

Bootstrap (CSS + JS) — for responsive and ready-made UI components

## Database
- MySQL DB `bookstore_db`

---

### 2️⃣ File structure & what files do

---

#### 🖥 Backend (Node) – folder like `bookstore-backend/`

**1. `server.js` – main backend file**
On start:
- Creates DB `bookstore_db` if not exists
- Creates 2 tables: `users`, `books`
- Inserts sample books if books table is empty

APIs:
| API | Method | Description |
|------|--------|-------------|
| `/api/auth/register` | POST | Register user |
| `/api/auth/login` | POST | Login, returns JWT token |
| `/api/books` | GET | Get all books / filter via `?search=` |

**2. `package.json`**
Contains backend dependencies and `"start": "node server.js"` script.

**3. `.env`**
```
DB_HOST=localhost
DB_USER=root
DB_PASSWORD=yourpassword
DB_NAME=bookstore_db
JWT_SECRET=ANY_RANDOM_SECRET_STRING
```

---

#### 🌐 Frontend (React) – folder like `bookstore-frontend/`

Key structure:
| Component/Page | Description |
|----------------|-------------|
| `Navbar.jsx` | Bootstrap navigation bar |
| `Home.jsx` | Landing page |
| `Register.jsx` | Sign-up form (POST `/api/auth/register`) |
| `Login.jsx` | Login (POST `/api/auth/login`) |
| `Catalog.jsx` | Search + display books (GET `/api/books`) |
| `App.jsx` | Routing setup |

---


### 🖥 How to run the Backend (Node.js)

1. Start MySQL.
2. Make sure `.env` contains correct DB credentials.
3. Open terminal inside the backend folder:
   ```
   cd bookstore-backend
   npm install
   node server.js
   ```
Backend will start at:
👉 http://localhost:3001


#### 🌐 Frontend (React)

```
cd bookstore-frontend
npm install
npm run dev
```

Frontend runs at: **http://localhost:5173**

⚠️ Both servers (`5173` React + `3001` Node) must run together.
